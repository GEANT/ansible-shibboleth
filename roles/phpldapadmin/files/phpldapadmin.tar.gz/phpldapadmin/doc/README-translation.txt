Please see http://phpldapadmin.sourceforge.net/Translate now for information on
translating PLA.
